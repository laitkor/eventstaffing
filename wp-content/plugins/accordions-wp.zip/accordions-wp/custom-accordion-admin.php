<div class="wrap">
	<h2 class="team-manager-admin-support">Support</h2>
	<div class="postbox team-manager-admin-area">
		<h3 class="eddpcs-admin-hthree">Support Forum</h3>
        <p>If you need any helps, please don't hesitate to post it on <a href="https://wordpress.org/support/plugin/accordions-wp" target="_blank">WordPress.org Support Forum</a> or <a href="https://themepoints.com/questions-answer/" target="_blank">Themepoints.com Support Forum</a>.</p><br />
		<h3>Submit a Review</h3>
		<p>We spend plenty of time to develop a plugin like this and give you freely to make your life easier. If you like this plugin, please <a href="https://wordpress.org/plugins/accordions-wp/" target="_blank">rate it 5 stars</a>. If you have any problems with the plugin, please <a href="https://themepoints.com/questions-answer/" target="_blank">let us know</a> before leaving a review.</p><br />
		<h3>Unlock More Features</h3>
		<p>Upgrading to the <a href="https://themepoints.com/product/wp-accordions-pro/" target="_blank"><span style="color: red;text-decoration:none;">Premium Version</span></a> would unlock more amazing features of this plugin.</p>
	</div>
</div>

